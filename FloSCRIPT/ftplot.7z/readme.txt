Unpublished work. � Siemens 2020
 
THIS SOFTWARE OR FILE (�Software�) CONTAINS TRADE SECRET AND PROPRIETARY INFORMATION THAT IS THE PROPERTY OF MENTOR GRAPHICS CORPORATION ("Mentor Graphics") OR ITS LICENSORS, AND IS SUBJECT TO LICENSE TERMS. If you have a signed license agreement with Mentor Graphics or a Mentor Graphics subsidiary for the product(s) with which this Software will be used, your use of this Software is subject to the scope of license and the software protection and security provisions of that agreement.  If you do not have such a signed agreement, your use is subject to Mentor Graphics� standard End-User License Agreement (�EULA�), which may be viewed at http://www.mentor.com/terms_conditions/enduser.
 
DISCLAIMER:  NOTWITHSTANDING ANYTHING TO THE CONTRARY IN YOUR SIGNED LICENSE AGREEMENT OR THE EULA, THIS SOFTWARE IS PROVIDED �AS IS� WITH ALL FAULTS AND WITH:
 
(A)          NO WARRANTY OF ANY KIND, express, implied or statutory, including any implied warranties of merchantability or fitness for a particular purpose, which Mentor Graphics disclaims to the maximum extent permitted by applicable law; and
 
(B)          NO INDEMNIFICATION FOR INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
 
LIMITATION OF LIABILITY:  Because this Software is provided �AS IS�, NEITHER MENTOR GRAPHICS NOR ITS LICENSORS SHALL BE LIABLE FOR ANY DAMAGES WHATSOEVER IN CONNECTION WITH THE SOFTWARE OR ITS USE.  Without limiting the foregoing, in no event will Mentor Graphics or its licensors be liable for indirect, special, incidental, or consequential damages (including lost profits or savings) whether based on contract, tort (including negligence), strict liability, or any other legal theory, even if Mentor Graphics or its licensors have been advised of the possibility of such damages.  THE FOREGOING LIMITATIONS SHALL APPLY TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW.
 
Unless otherwise agreed in writing, Mentor Graphics has no obligation to support or otherwise maintain Software.